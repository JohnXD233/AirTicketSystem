create PROCEDURE                     SALERECORDPAGESPROC (
ROWFORPAGE IN NUMBER  --每页显示的记录数
, PAGENUMBER IN NUMBER ,  --页号,当前页
 imonth in varchar2,   --查询 某月的  销售记录
 inetcode in number,   --指定销售网点
 iflightno in number,  --航班no， 该销售网点 该航班的销售记录
cur out sys_refcursor
)AS 
BEGIN

--select  to_char(sysdate, 'MM' )  from dual;

  open cur for
  
SELECT * FROM
(
   SELECT A.*, ROWNUM RN

--(SELECT * FROM salerecord where to_char(saletime,'MM')=imonth) 这句话找出 06 月份的销售记录，我这边一共只有一条销售记录
   FROM (SELECT * FROM air.salerecord where to_char(saletime,'MM')=imonth and netid=(select netid from netdealer where netcode=inetcode) and flightid=(select flightid from flight where flightno=iflightno)) A   --这边是表名,事先写好  and tocity=tocity and planstarttime=plantime

   WHERE ROWNUM <= PAGENUMBER*ROWFORPAGE   --这个算法非常重要

)

WHERE RN >  (PAGENUMBER-1)*ROWFORPAGE;  --表示 行索引区间（在总行数到0之间的） ( (PAGENUMBER-1)*ROWSUMFORPAGE , PAGENUMBER*ROWSUMFORPAGE )
--分页查询表
END SALERECORDPAGESPROC;
/

