create trigger FLIGHTTRIGGER1
  before insert
  on FLIGHT
  for each row
  BEGIN
  select flightINSERT.nextval into:new.flightid from dual;
END;
/

