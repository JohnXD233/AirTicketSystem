create PROCEDURE     FLIGHTPAGESPROC2 
(
  ROWFORPAGE IN NUMBER 
, PAGENUMBER IN NUMBER ,  --区别于FLIGHTPAGESPROC ，输入参数不一样
fcity in varchar,   --这边注意参数不要和表中字段重名
tcity in varchar,
iflightno in varchar2  --航班编号  不是主键航班ID
,cur out sys_refcursor
) AS 
BEGIN
  open cur for
  
SELECT * FROM
(
   SELECT A.*, ROWNUM RN

   FROM (SELECT * FROM AIR.FLIGHT where fromcity=fcity and tocity=tcity and flightno=iflightno ) A   --这边是表名,事先写好  and tocity=tocity and planstarttime=plantime

   WHERE ROWNUM <= PAGENUMBER*ROWFORPAGE   --这个算法非常重要

)

WHERE RN >  (PAGENUMBER-1)*ROWFORPAGE;
END FLIGHTPAGESPROC2;
/

