create trigger NETDEALERTRIGGER1
  before insert
  on NETDEALER
  for each row
  BEGIN
select NETDEALERINSERT.nextval into:new.netid from dual;
END;
/

