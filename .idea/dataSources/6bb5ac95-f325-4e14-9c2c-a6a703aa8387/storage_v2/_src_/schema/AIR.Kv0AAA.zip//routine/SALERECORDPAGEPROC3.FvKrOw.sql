create PROCEDURE         SALERECORDPAGEPROC3 
(
  ROWFORPAGE IN NUMBER 
, PAGENUMBER IN NUMBER ,
imonth in varchar2,
iflightno in number,
cur out sys_refcursor
) AS 
BEGIN
  open cur for
SELECT * FROM
(
   SELECT A.*, ROWNUM RN

   FROM (SELECT * FROM air.salerecord where to_char(saletime,'MM')=imonth and flightid=(select flightid from flight where flightno=iflightno) ) A   --这边是表名,事先写好  and tocity=tocity and planstarttime=plantime
   WHERE ROWNUM <= PAGENUMBER*ROWFORPAGE   
)

WHERE RN >  (PAGENUMBER-1)*ROWFORPAGE;
END SALERECORDPAGEPROC3;
/

