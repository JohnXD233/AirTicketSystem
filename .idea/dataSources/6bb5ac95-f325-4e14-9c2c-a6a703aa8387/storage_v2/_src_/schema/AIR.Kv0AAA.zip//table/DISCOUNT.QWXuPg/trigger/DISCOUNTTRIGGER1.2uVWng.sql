create trigger DISCOUNTTRIGGER1
  before insert
  on DISCOUNT
  for each row
  BEGIN
  select discountINSERT.nextval into:new.discountid from dual;
END;
/

