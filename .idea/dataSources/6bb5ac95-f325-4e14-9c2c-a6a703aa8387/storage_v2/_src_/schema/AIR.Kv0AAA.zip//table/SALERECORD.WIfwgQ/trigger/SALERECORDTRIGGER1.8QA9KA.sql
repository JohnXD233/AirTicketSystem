create trigger SALERECORDTRIGGER1
  before insert
  on SALERECORD
  for each row
  BEGIN
  select SALERECORDINSERT.nextval into:new.saleid from dual;
END;
/

