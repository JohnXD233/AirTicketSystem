create PROCEDURE         SALERECORDPAGEPROC2 
(
  ROWFORPAGE IN NUMBER 
, PAGENUMBER IN NUMBER ,
imonth in varchar2,   --查询 某月的  销售记录
 inetcode in number,   --指定销售网点 
 cur out sys_refcursor
) AS 
BEGIN
 open cur for
SELECT * FROM
(
   SELECT A.*, ROWNUM RN
--(SELECT * FROM salerecord where to_char(saletime,'MM')=imonth) 这句话找出 06 月份的销售记录，我这边一共只有一条销售记录
   FROM (SELECT * FROM air.salerecord where to_char(saletime,'MM')=imonth and netid=(select netid from netdealer where netcode=inetcode) ) A   --这边是表名,事先写好  and tocity=tocity and planstarttime=plantime
   WHERE ROWNUM <= PAGENUMBER*ROWFORPAGE   
)

WHERE RN >  (PAGENUMBER-1)*ROWFORPAGE;
END SALERECORDPAGEPROC2;
/

