create PROCEDURE         NETDEALERPAGESPROC 
(
  ROWFORPAGE IN NUMBER  --销售网点的分页查询
, PAGENUMBER IN NUMBER ,
inetcode in varchar2,  --这边netcode和 netname 判断用的是or
inetname in varchar2,
cur out sys_refcursor
) AS 
BEGIN
   open cur for
  
SELECT * FROM
(
   SELECT A.*, ROWNUM RN

   FROM (SELECT * FROM AIR.NETDEALER where netcode=inetcode or netname=inetname ) A   --这边是表名,事先写好  and tocity=tocity and planstarttime=plantime

   WHERE ROWNUM <= PAGENUMBER*ROWFORPAGE   --这个算法非常重要

)

WHERE RN >  (PAGENUMBER-1)*ROWFORPAGE; 
END NETDEALERPAGESPROC;
/

