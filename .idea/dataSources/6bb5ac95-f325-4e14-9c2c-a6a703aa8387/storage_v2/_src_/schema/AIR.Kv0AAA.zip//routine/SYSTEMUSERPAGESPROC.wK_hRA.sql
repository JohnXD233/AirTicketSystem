create PROCEDURE         SYSTEMUSERPAGESPROC 
(
  ROWFORPAGE IN NUMBER  --每页显示的记录数
, PAGENUMBER IN NUMBER ,  --页号,当前页
 iusername  in varchar2,
 cur out sys_refcursor
) AS 
BEGIN
   open cur for
  
SELECT * FROM
(
   SELECT A.*, ROWNUM RN

   FROM (SELECT * FROM AIR.SYSTEMUSER where username=iusername) A   --根据用户名查询管理员，一般如果用户名 001 唯一，只有一条

   WHERE ROWNUM <= PAGENUMBER*ROWFORPAGE   --这个算法非常重要

)

WHERE RN >  (PAGENUMBER-1)*ROWFORPAGE;  --表示 行索引区间（在总行数到0之间的） ( (PAGENUMBER-1)*ROWSUMFORPAGE , PAGENUMBER*ROWSUMFORPAGE )
--分页查询表
END SYSTEMUSERPAGESPROC;
/

