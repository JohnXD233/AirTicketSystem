create trigger BOUNCERECORDTRIGGER1
  before insert
  on BOUNCERECORD
  for each row
  BEGIN
  select bounceRECORDINSERT.nextval into:new.bounceid from dual;
END;
/

