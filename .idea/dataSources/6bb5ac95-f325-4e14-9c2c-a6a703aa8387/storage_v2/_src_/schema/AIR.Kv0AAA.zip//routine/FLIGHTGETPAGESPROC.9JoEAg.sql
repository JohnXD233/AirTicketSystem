create PROCEDURE         FLIGHTGETPAGESPROC 
(
  ROWFORPAGE IN NUMBER ,  --每页显示行数
  pages out NUMBER  --总页数，这边是用于上下页切换，和首末页的
) AS 
rowsum int:=0;
BEGIN
  select count(*) into rowsum from AIR.FLIGHT;  --航班信息表的总页数计算proc
  if(mod(rowsum,ROWFORPAGE)=0) then
   pages:=rowsum/ROWFORPAGE;    --  :=  表示赋值
   else
   pages:=rowsum/ROWFORPAGE+1;
  end if;
END FLIGHTGETPAGESPROC;
/

