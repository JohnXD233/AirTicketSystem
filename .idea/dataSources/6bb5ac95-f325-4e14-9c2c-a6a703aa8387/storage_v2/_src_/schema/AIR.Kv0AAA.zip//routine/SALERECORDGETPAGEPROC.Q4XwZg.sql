create PROCEDURE     SALERECORDGETPAGEPROC 
(
  ROWFORPAGE IN NUMBER   --计算销售记录的总页数
, PAGES OUT NUMBER 
) AS 
rowsum int:=0;
BEGIN
  select count(*) into rowsum from AIR.SALERECORD;  --销售记录表的总页数计算proc
  if(mod(rowsum,ROWFORPAGE)=0) then
   pages:=rowsum/ROWFORPAGE;    --  :=  表示赋值
   else
   pages:=rowsum/ROWFORPAGE+1;
  end if;
END SALERECORDGETPAGEPROC;
/

