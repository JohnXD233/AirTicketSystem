create trigger SYSTEMUSERTRIGGER1
  before insert
  on SYSTEMUSER
  for each row
  BEGIN
  select systemuserINSERT.nextval into:new.userid from dual;
END;
/

